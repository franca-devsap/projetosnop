# FE Binding Contract - ZSD Forecast Unrestricted LTP 2026

## Status

Este contrato documenta a evolucao recomendada para RAP/OData V4 sem alterar o prototipo atual, que continua sendo SAPUI5 Freestyle com `JSONModel` e dados mockados em `webapp/model/mockData.json`.

## Servico Recomendado

- Service Definition: `ZUI_FORECAST_UNRESTRICTED_O4`
- URI proposta: `/sap/opu/odata4/sap/zui_forecast_unrestricted_o4/srvd/sap/zui_forecast_unrestricted_o4/0001/`
- Protocolo: OData V4
- Draft: recomendado para montagem de previsao antes do salvamento definitivo

## Entidades

### ForecastPlans

- CDS Root: `ZI_ForecastPlan`
- Chave: `ForecastId`
- Campos obrigatorios: `ForecastYear`, `DateFrom`, `DateTo`, `Plant`, `SalesTeam`
- Campos de busca/filtro: `SearchTerm`, `Plant`, `SalesTeam`, `DateFrom`, `DateTo`
- Totais somente leitura: `TotalPortfolio`, `TotalQuotation`, `TotalBudget`, `TotalBilled`, `TotalForecast`, `GapAmount`, `Currency`
- Status: `Status`, `ApprovalStage`

### ForecastPlanItems

- CDS Child: `ZI_ForecastPlanItem`
- Chaves: `ForecastId`, `ItemId`
- Campos: `ItemType`, `SourceDocument`, `Customer`, `Product`, `MtsMto`, `Situation`, `Quantity`, `UnitValue`, `TotalValue`, `FreightValue`, `Probability`, `WeightedValue`, `ForecastDate`, `Month`, `Year`, `Currency`, `Status`
- Regra atual do prototipo: apos adicionar a Previsao, os itens ficam somente visualizacao.

### Source Projections

- `PortfolioItems`: documentos de carteira
- `QuotationItems`: cotacoes
- `BudgetItems`: objetos de budget mensal
- `BilledItems`: faturado do ano corrente
- `MonthlyDetail`: detalhe mensal consolidado

## Value Helps

Criar value helps CDS para:

- `Plant`
- `SalesTeam`
- `Customer`
- `Product`
- `SourceDocument`
- `BudgetName`

Todos devem suportar `@Search.searchable` e retornar codigo + descricao quando existir.

## Acoes RAP

- `addPortfolioItems`: adiciona itens de carteira ao draft da previsao.
- `addQuotationItems`: adiciona cotacoes ao draft da previsao.
- `addBudgetItems`: adiciona itens de budget ao draft da previsao.
- `addManualItem`: cria item manual quando permitido.
- `saveForecast`: persiste a previsao e recalcula totais.
- `clearStagedItems`: limpa itens temporarios apos salvamento.
- `simulateForecast`: recalcula grafico, gap e detalhes sem persistir.
- `approveSales`, `approveCompliance`, `approveFinance`: etapas de aprovacao.

## Anotacoes UI Recomendadas

- `@UI.headerInfo` para `ForecastPlans`.
- `@UI.selectionField` para termo de pesquisa, data, unidade fabril e equipe de vendas.
- `@UI.lineItem` para list report inicial e tabelas de objetos.
- Facets para detalhe mensal, itens da previsao e comparativo grafico.
- Acoes expostas no toolbar padrao quando migrar para Fiori Elements.

## Regras Funcionais Que Devem Ser Preservadas

- O filtro de mes nas abas filtra somente os objetos selecionaveis, nao o grafico principal.
- O grafico principal compara Budget anual mes a mes com a composicao Carteira + Cotacoes + Budget/Previsao.
- Ao salvar uma previsao, os itens adicionados devem ser persistidos, a tela de montagem deve ser limpa para nova composicao e a lista deve ser atualizada.
- As unidades monetarias devem ser formatadas dinamicamente: usar valores absolutos quando nao atingirem milhoes e abreviar para Mi quando aplicavel.

## Pendencias Para Migracao Real

- Confirmar pacote ABAP, nomes finais das CDS views e autorizacoes.
- Confirmar origem oficial de carteira, cotacao, budget e faturamento.
- Confirmar se a aplicacao tera Draft RAP ou somente acoes transacionais.
- Definir tabelas persistentes para cabecalho e itens da previsao irrestrita.
- Definir se upload Excel continuara existindo como extensao Freestyle ou se sera substituido por carga backend.
